'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Suporte extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      Suporte.belongsTo(models.Professor, { foreignKey: 'ProfessorId' });
      Suporte.belongsTo(models.Aluno, { foreignKey: 'AlunoId' });
    }
    
  }
  Suporte.init({
    ProfessorId: DataTypes.INTEGER,
    AlunoId: DataTypes.INTEGER
  }, {
    sequelize,
    modelName: 'Suporte',
  });
  return Suporte;
};