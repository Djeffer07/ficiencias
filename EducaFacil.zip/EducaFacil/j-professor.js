const inputPass = document.getElementById('senha');
const btnShowPass = document.getElementById('btn-senha');

btnShowPass.addEventListener('click', function () {
    if (inputPass.type === 'password') {
        inputPass.type = 'text';
        btnShowPass.classList.remove('bi-eye-slash-fill');
        btnShowPass.classList.add('bi-eye-fill');
    } else {
        inputPass.type = 'password';
        btnShowPass.classList.remove('bi-eye-fill');
        btnShowPass.classList.add('bi-eye-slash-fill');
    }
});

