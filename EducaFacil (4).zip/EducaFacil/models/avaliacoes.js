'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Avaliacoes extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      Avaliacoes.belongsTo(models.Aluno, { foreignKey: 'AlunoId' });
      Avaliacoes.belongsTo(models.Professor, { foreignKey: 'ProfessorId' });
    }
    
  }
  Avaliacoes.init({
    AtividadeId: DataTypes.INTEGER,
    ProvaId: DataTypes.INTEGER,
    AlunoId: DataTypes.INTEGER,
    ProfessorId: DataTypes.INTEGER
  }, {
    sequelize,
    modelName: 'Avaliacoes',
  });
  return Avaliacoes;
};