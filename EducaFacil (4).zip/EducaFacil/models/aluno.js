'use strict';
const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class Aluno extends Model {
    static associate(models) {
      Aluno.belongsTo(models.Administrador, { foreignKey: 'AdministradorId' });
      Aluno.hasMany(models.Avaliacoes, { foreignKey: 'AlunoId' });
      Aluno.belongsToMany(models.Professor, { through: 'ProfessorAlunos', foreignKey: 'AlunoId' });
    }
  }

  Aluno.init({
    email: DataTypes.STRING,
    nome: DataTypes.STRING,
    senha: DataTypes.STRING
  }, {
    sequelize,
    modelName: 'Aluno',
  });

  return Aluno;
};
