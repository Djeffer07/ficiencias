'use strict';
const {
  Model
} = require('sequelize');
const aluno = require('./aluno');
module.exports = (sequelize, DataTypes) => {
  class Administrador extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      Administrador.hasMany(models.Aluno, { foreignKey: 'AlunoId' });
      Administrador.hasMany(models.Professor, { foreignKey: 'ProfessorId' });
    }
    
  }
  Administrador.init({
    email: DataTypes.STRING,
    nome: DataTypes.STRING,
    senha: DataTypes.STRING,
    AlunoId: DataTypes.INTEGER,
    ProfessorId: DataTypes.INTEGER
  }, {
    sequelize,
    modelName: 'Administrador',
  });
  return Administrador;
};