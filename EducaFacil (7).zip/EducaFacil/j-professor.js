const inputPass = document.getElementById('senha');
const btnShowPass = document.getElementById('btn-senha');

btnShowPass.addEventListener('click', function () {
    if (inputPass.type === 'password') {
        inputPass.type = 'text';
        btnShowPass.classList.remove('bi-eye-slash-fill');
        btnShowPass.classList.add('bi-eye-fill');
    } else {
        inputPass.type = 'password';
        btnShowPass.classList.remove('bi-eye-fill');
        btnShowPass.classList.add('bi-eye-slash-fill');
    }
});

document.querySelector("form").addEventListener("submit", function (e) {
    e.preventDefault(); 

    document.getElementById("documentos-modal").style.display = "flex";
});

document.getElementById("enviar-documentos").addEventListener("click", function () {
    const ctps = document.getElementById("ctps").files.length;
    const ctc = document.getElementById("ctc").files.length;

    if (ctps > 0 && ctc > 0) {
        document.getElementById("confirmation-message").style.display = "block";

        setTimeout(() => {
            window.location.href = "login_professor.html";
        }, 3000);
    } else {
        alert("Por favor, anexe os dois documentos para continuar.");
    }
});

document.getElementById("ctps").addEventListener("change", function () {
    const fileName = document.getElementById("ctps").files[0]?.name || 'Nenhum arquivo selecionado';
    document.querySelector('.file-name-ctps').textContent = `Arquivo selecionado: ${fileName}`;
});

document.getElementById("ctc").addEventListener("change", function () {
    const fileName = document.getElementById("ctc").files[0]?.name || 'Nenhum arquivo selecionado';
    document.querySelector('.file-name-ctc').textContent = `Arquivo selecionado: ${fileName}`;
});
