function showSection(section) {
    const contents = document.querySelectorAll('.tab-content');
    const buttons = document.querySelectorAll('.tab-button');

    contents.forEach(content => {
        content.classList.remove('active');
    });

    buttons.forEach(button => {
        button.classList.remove('active');
    });

    document.getElementById(section).classList.add('active');
    document.querySelector(`.tab-button[onclick="showSection('${section}')"]`).classList.add('active');
}

function filterContent() {
    const level = document.getElementById('level-select').value;
    const subject = document.getElementById('subject-select').value;
    const search = document.getElementById('search-bar').value.toLowerCase();
    const videos = document.querySelectorAll('.video-item');

    videos.forEach(video => {
        const videoLevel = video.classList.contains(level);
        const videoSubject = video.classList.contains(subject);
        const videoTitle = video.querySelector('h3').textContent.toLowerCase();

        if ((level === '' || videoLevel) && 
            (subject === '' || videoSubject) && 
            (search === '' || videoTitle.includes(search))) {
            video.style.display = 'block'; 
        } else {
            video.style.display = 'none'; 
        }
    });
}

function showSection(sectionId) {
    const sections = document.querySelectorAll('.tab-content');
    sections.forEach(section => {
        section.classList.remove('active');
        if (section.id === sectionId) {
            section.classList.add('active');
        }
    });

    const buttons = document.querySelectorAll('.tab-button');
    buttons.forEach(button => {
        button.classList.remove('active');
        if (button.textContent === sectionId) {
            button.classList.add('active');
        }
    });
}
